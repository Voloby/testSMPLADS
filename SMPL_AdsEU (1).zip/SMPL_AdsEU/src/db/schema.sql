-- SMPL Ads Database Schema
-- Compatible with PostgreSQL 14+
-- For MySQL: replace SERIAL with AUTO_INCREMENT, JSONB with JSON, INET with VARCHAR(45)

-- Services table
CREATE TABLE IF NOT EXISTS services (
    id SERIAL PRIMARY KEY,
    slug VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    icon VARCHAR(50),
    color_class VARCHAR(50),
    sort_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Service features
CREATE TABLE IF NOT EXISTS service_features (
    id SERIAL PRIMARY KEY,
    service_id INT REFERENCES services(id) ON DELETE CASCADE,
    feature_text VARCHAR(255) NOT NULL,
    sort_order INT DEFAULT 0
);

-- Leads from contact form
CREATE TABLE IF NOT EXISTS leads (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(30) NOT NULL,
    email VARCHAR(100),
    company VARCHAR(100),
    message TEXT,
    source VARCHAR(50) DEFAULT 'website',
    status VARCHAR(20) DEFAULT 'new',
    assigned_to INT,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Chat messages
CREATE TABLE IF NOT EXISTS chat_messages (
    id SERIAL PRIMARY KEY,
    session_id VARCHAR(64) NOT NULL,
    sender_type VARCHAR(10) NOT NULL CHECK (sender_type IN ('user', 'ai', 'agent')),
    message TEXT NOT NULL,
    metadata JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Chat sessions
CREATE TABLE IF NOT EXISTS chat_sessions (
    id SERIAL PRIMARY KEY,
    session_id VARCHAR(64) UNIQUE NOT NULL,
    user_name VARCHAR(100),
    user_email VARCHAR(100),
    user_phone VARCHAR(30),
    status VARCHAR(20) DEFAULT 'active',
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Admin users
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role VARCHAR(20) DEFAULT 'manager',
    office_location VARCHAR(50),
    is_active BOOLEAN DEFAULT true,
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Contacts (CRM)
CREATE TABLE IF NOT EXISTS contacts (
    id SERIAL PRIMARY KEY,
    lead_id INT REFERENCES leads(id) ON DELETE SET NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(30),
    company VARCHAR(100),
    tags TEXT[],
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_leads_status ON leads(status);
CREATE INDEX IF NOT EXISTS idx_leads_created ON leads(created_at);
CREATE INDEX IF NOT EXISTS idx_chat_sessions_id ON chat_sessions(session_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_session ON chat_messages(session_id);
CREATE INDEX IF NOT EXISTS idx_contacts_email ON contacts(email);

-- Auto-update trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_leads_updated_at BEFORE UPDATE ON leads
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_contacts_updated_at BEFORE UPDATE ON contacts
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_services_updated_at BEFORE UPDATE ON services
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Seed data
INSERT INTO services (slug, name, title, description, icon, color_class, sort_order) VALUES
('content', 'SMPL Content', 'Content That Sells', 'Short-form videos and authentic UGC reviews.', 'Video', 'bg-purple-100', 1),
('traffic', 'SMPL Traffic', 'Customer Flow', 'Professional setup for Meta, Google, and TikTok Ads.', 'TrendingUp', 'bg-blue-100', 2),
('systems', 'SMPL Systems', 'Sales Automation', 'Setting up lead processing and CRM automation.', 'Settings', 'bg-green-100', 3),
('websites', 'SMPL Websites', 'Modern Websites', 'Fast, minimalist, high-converting websites.', 'Globe', 'bg-orange-100', 4);

INSERT INTO service_features (service_id, feature_text, sort_order) VALUES
(1, 'Reels & TikTok Production', 1),
(1, 'UGC Content Creation', 2),
(1, 'Viral Scripting', 3),
(2, 'Targeted Social Media Ads', 1),
(2, 'Google Search & Display', 2),
(2, 'High-ROI Retargeting', 3),
(3, 'CRM Implementation', 1),
(3, 'Lead Auto-responders', 2),
(3, 'Sales Funnel Optimization', 3),
(4, 'High-Conversion Landings', 1),
(4, 'Full Mobile Optimization', 2),
(4, 'Ultra-fast Loading Speeds', 3);