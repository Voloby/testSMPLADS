import { useEffect, useState } from 'react'
import Header from './components/Header'
import Hero from './components/Hero'
import Services from './components/Services'
import WhyUs from './components/WhyUs'
import ContactForm from './components/ContactForm'
import Footer from './components/Footer'
import AIChat from './components/AIChat'

function App() {
  const [theme, setTheme] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('theme') || 
        (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
    }
    return 'light'
  })

  useEffect(() => {
    const root = window.document.documentElement
    if (theme === 'dark') {
      root.classList.add('dark')
    } else {
      root.classList.remove('dark')
    }
    localStorage.setItem('theme', theme)
  }, [theme])

  const toggleTheme = () => setTheme(prev => prev === 'light' ? 'dark' : 'light')

  return (
    <div className="bg-white dark:bg-darkBg text-primary dark:text-gray-100 min-h-screen transition-colors duration-300">
      <Header toggleTheme={toggleTheme} theme={theme} />
      <main>
        <Services />
        <Hero />
        <WhyUs />
        <ContactForm />
      </main>
      <Footer />
      <AIChat />
    </div>
  )
}

export default App