# SMPL Ads — React Website

Modern React website for SMPL Ads digital marketing agency.

## Tech Stack

- **React 18** + Vite
- **Tailwind CSS** (dark mode support)
- **Framer Motion** — animations
- **Lucide React** — icons
- **React Router** — ready for multi-page expansion

## Features

- Dark / Light theme with localStorage persistence
- Animated tabs (Services section)
- Form validation with loading states
- AI Chat widget with message history
- Fully responsive (mobile-first)
- Scroll-triggered animations
- SEO-ready structure

## Quick Start

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Database

SQL schema located in `src/db/schema.sql` — ready for PostgreSQL/MySQL backend integration.

### API Endpoints to implement:

- `POST /api/leads` — submit contact form
- `POST /api/chat/message` — send chat message
- `GET /api/chat/history/:sessionId` — get chat history

## Project Structure

```
src/
├── components/
│   ├── Header.jsx
│   ├── Hero.jsx
│   ├── Services.jsx
│   ├── WhyUs.jsx
│   ├── ContactForm.jsx
│   ├── Footer.jsx
│   └── AIChat.jsx
├── hooks/
│   └── useLocalStorage.js
├── db/
│   └── schema.sql
├── App.jsx
├── main.jsx
└── index.css
```