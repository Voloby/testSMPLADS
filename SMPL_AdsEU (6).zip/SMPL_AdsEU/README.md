# SMPL Ads — React + Firebase Chat

## Що працює

- Клієнт пише на сайті → повідомлення зберігається в Firebase
- Менеджер отримує сповіщення в WhatsApp (через wa.me)
- Менеджер відповідає в адмінці `/admin` → клієнт бачить відповідь на сайті

## Налаштування Firebase

1. Створи проєкт на [firebase.google.com](https://firebase.google.com)
2. Увімкни **Realtime Database** (режим test: `.read`/`.write` = `true`)
3. Додай Web App → скопіюй конфіг в `src/lib/firebase.js`
4. Встанови залежності: `npm install`
5. Запусти: `npm run dev`

## Деплой

```bash
npm run build
```

Завантаж папку `dist/` на хостинг (Spaceship, Vercel, Netlify).

## Адмін-панель

Відкрий `https://your-site.com/admin`

## Важливо

- Заміни `WHATSAPP_NUMBER` в `AIChat.jsx` на свій номер
- Для продакшену зміни правила Firebase Database на безпечні