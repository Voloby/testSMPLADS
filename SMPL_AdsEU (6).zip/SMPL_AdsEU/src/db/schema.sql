-- SMPL Ads Database Schema v2
-- With WhatsApp integration & Live Chat support
-- Compatible with PostgreSQL 14+

-- Services table
CREATE TABLE IF NOT EXISTS services (
    id SERIAL PRIMARY KEY,
    slug VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    icon VARCHAR(50),
    color_class VARCHAR(50),
    sort_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Service features
CREATE TABLE IF NOT EXISTS service_features (
    id SERIAL PRIMARY KEY,
    service_id INT REFERENCES services(id) ON DELETE CASCADE,
    feature_text VARCHAR(255) NOT NULL,
    sort_order INT DEFAULT 0
);

-- Leads from contact form
CREATE TABLE IF NOT EXISTS leads (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(30) NOT NULL,
    email VARCHAR(100),
    company VARCHAR(100),
    message TEXT,
    source VARCHAR(50) DEFAULT 'website',
    status VARCHAR(20) DEFAULT 'new',
    assigned_to INT,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Chat sessions (live chat)
CREATE TABLE IF NOT EXISTS chat_sessions (
    id SERIAL PRIMARY KEY,
    session_id VARCHAR(64) UNIQUE NOT NULL,
    user_name VARCHAR(100),
    user_phone VARCHAR(30),
    user_email VARCHAR(100),
    status VARCHAR(20) DEFAULT 'active',
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Chat messages
CREATE TABLE IF NOT EXISTS chat_messages (
    id SERIAL PRIMARY KEY,
    session_id VARCHAR(64) NOT NULL REFERENCES chat_sessions(session_id) ON DELETE CASCADE,
    sender_type VARCHAR(10) NOT NULL CHECK (sender_type IN ('user', 'ai', 'manager', 'system')),
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT false,
    metadata JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- WhatsApp forwarding log
CREATE TABLE IF NOT EXISTS whatsapp_logs (
    id SERIAL PRIMARY KEY,
    session_id VARCHAR(64) NOT NULL,
    message_id INT REFERENCES chat_messages(id),
    provider VARCHAR(20) NOT NULL, -- 'ultramsg', 'callmebot', 'meta'
    target_phone VARCHAR(30),      -- for direct messages
    group_id VARCHAR(100),         -- for group messages
    status VARCHAR(20) DEFAULT 'pending', -- pending, sent, failed
    response_body JSONB,
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Admin users
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role VARCHAR(20) DEFAULT 'manager',
    office_location VARCHAR(50),
    whatsapp_phone VARCHAR(30),    -- for receiving forwarded messages
    is_active BOOLEAN DEFAULT true,
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Contacts (CRM)
CREATE TABLE IF NOT EXISTS contacts (
    id SERIAL PRIMARY KEY,
    lead_id INT REFERENCES leads(id) ON DELETE SET NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(30),
    company VARCHAR(100),
    tags TEXT[],
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_leads_status ON leads(status);
CREATE INDEX IF NOT EXISTS idx_leads_created ON leads(created_at);
CREATE INDEX IF NOT EXISTS idx_chat_sessions_id ON chat_sessions(session_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_session ON chat_messages(session_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_created ON chat_messages(created_at);
CREATE INDEX IF NOT EXISTS idx_whatsapp_session ON whatsapp_logs(session_id);
CREATE INDEX IF NOT EXISTS idx_contacts_email ON contacts(email);

-- Auto-update trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_leads_updated_at BEFORE UPDATE ON leads
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_contacts_updated_at BEFORE UPDATE ON contacts
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_services_updated_at BEFORE UPDATE ON services
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_chat_sessions_updated_at BEFORE UPDATE ON chat_sessions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Seed data
INSERT INTO services (slug, name, title, description, icon, color_class, sort_order) VALUES
('content', 'SMPL Content', 'Content That Sells', 'Short-form videos and authentic UGC reviews.', 'Video', 'bg-purple-100', 1),
('traffic', 'SMPL Traffic', 'Customer Flow', 'Professional setup for Meta, Google, and TikTok Ads.', 'TrendingUp', 'bg-blue-100', 2),
('systems', 'SMPL Systems', 'Sales Automation', 'Setting up lead processing and CRM automation.', 'Settings', 'bg-green-100', 3),
('websites', 'SMPL Websites', 'Modern Websites', 'Fast, minimalist, high-converting websites.', 'Globe', 'bg-orange-100', 4)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO service_features (service_id, feature_text, sort_order) VALUES
(1, 'Reels & TikTok Production', 1),
(1, 'UGC Content Creation', 2),
(1, 'Viral Scripting', 3),
(2, 'Targeted Social Media Ads', 1),
(2, 'Google Search & Display', 2),
(2, 'High-ROI Retargeting', 3),
(3, 'CRM Implementation', 1),
(3, 'Lead Auto-responders', 2),
(3, 'Sales Funnel Optimization', 3),
(4, 'High-Conversion Landings', 1),
(4, 'Full Mobile Optimization', 2),
(4, 'Ultra-fast Loading Speeds', 3)
ON CONFLICT DO NOTHING;

-- Seed admin user (password: admin123 — CHANGE IN PRODUCTION!)
-- bcrypt hash for 'admin123'
INSERT INTO users (email, password_hash, full_name, role, whatsapp_phone)
VALUES ('admin@smplads.com', '$2b$10$YourHashedPasswordHere', 'Admin User', 'admin', '+12015550123')
ON CONFLICT (email) DO NOTHING;