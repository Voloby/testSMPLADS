// backend/server.js — Example Node.js backend for SMPL Ads
// npm install express cors pg bcryptjs jsonwebtoken axios dotenv

require('dotenv').config()
const express = require('express')
const cors = require('cors')
const { Pool } = require('pg')
const axios = require('axios')
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')

const app = express()
app.use(cors())
app.use(express.json())

const pool = new Pool({ connectionString: process.env.DATABASE_URL })

// ========== AUTH MIDDLEWARE ==========
const auth = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1]
  if (!token) return res.status(401).json({ error: 'Unauthorized' })
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET)
    next()
  } catch {
    res.status(401).json({ error: 'Invalid token' })
  }
}

// ========== CHAT API ==========

// Save message & forward to WhatsApp
app.post('/api/chat/message', async (req, res) => {
  const { sessionId, text, senderType, metadata } = req.body

  try {
    // Upsert session
    await pool.query(`
      INSERT INTO chat_sessions (session_id, user_name, user_phone, user_email)
      VALUES ($1, $2, $3, $4)
      ON CONFLICT (session_id) DO UPDATE SET
        last_activity = CURRENT_TIMESTAMP,
        user_name = COALESCE(EXCLUDED.user_name, chat_sessions.user_name),
        user_phone = COALESCE(EXCLUDED.user_phone, chat_sessions.user_phone)
    `, [sessionId, metadata?.name, metadata?.phone, metadata?.email])

    // Save message
    const msg = await pool.query(`
      INSERT INTO chat_messages (session_id, sender_type, message, metadata)
      VALUES ($1, $2, $3, $4) RETURNING *
    `, [sessionId, senderType, text, metadata || {}])

    res.json(msg.rows[0])
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: err.message })
  }
})

// Forward to WhatsApp group (Ultramsg example)
app.post('/api/chat/forward-whatsapp', async (req, res) => {
  const { sessionId, text, target } = req.body

  try {
    // Ultramsg API
    const response = await axios.post('https://api.ultramsg.com/instance12345/messages/chat', {
      token: process.env.ULTRAMSG_TOKEN,
      to: target || process.env.WHATSAPP_GROUP_ID, // group ID format: 120363000000000000@g.us
      body: `🔔 SMPL Chat\nSession: ${sessionId.slice(0, 12)}...\n\n${text}\n\nReply here or open: ${process.env.ADMIN_URL}/admin`,
    })

    await pool.query(`
      INSERT INTO whatsapp_logs (session_id, provider, group_id, status, response_body)
      VALUES ($1, 'ultramsg', $2, 'sent', $3)
    `, [sessionId, target, JSON.stringify(response.data)])

    res.json({ sent: true })
  } catch (err) {
    console.error('WhatsApp forward failed:', err.message)
    await pool.query(`
      INSERT INTO whatsapp_logs (session_id, provider, group_id, status, error_message)
      VALUES ($1, 'ultramsg', $2, 'failed', $3)
    `, [sessionId, target, err.message])
    res.status(500).json({ error: 'Forward failed' })
  }
})

// Get chat history
app.get('/api/chat/history/:sessionId', async (req, res) => {
  const { sessionId } = req.params
  const messages = await pool.query(`
    SELECT * FROM chat_messages
    WHERE session_id = $1
    ORDER BY created_at ASC
  `, [sessionId])
  res.json({ messages: messages.rows })
})

// Get active chats
app.get('/api/chat/active', auth, async (req, res) => {
  const sessions = await pool.query(`
    SELECT s.*,
      (SELECT COUNT(*) FROM chat_messages m WHERE m.session_id = s.session_id AND m.sender_type = 'user' AND m.is_read = false) as unread_count,
      (SELECT message FROM chat_messages m WHERE m.session_id = s.session_id ORDER BY created_at DESC LIMIT 1) as last_message
    FROM chat_sessions s
    WHERE s.status = 'active'
    ORDER BY s.last_activity DESC
  `)
  res.json(sessions.rows)
})

// Manager reply
app.post('/api/chat/reply', auth, async (req, res) => {
  const { sessionId, text, managerId } = req.body
  const msg = await pool.query(`
    INSERT INTO chat_messages (session_id, sender_type, message)
    VALUES ($1, 'manager', $2) RETURNING *
  `, [sessionId, text])

  // Mark user messages as read
  await pool.query(`
    UPDATE chat_messages SET is_read = true
    WHERE session_id = $1 AND sender_type = 'user'
  `, [sessionId])

  res.json(msg.rows[0])
})

// ========== LEADS API ==========
app.post('/api/leads', async (req, res) => {
  const { name, phone, email, company, message, source } = req.body
  const lead = await pool.query(`
    INSERT INTO leads (name, phone, email, company, message, source)
    VALUES ($1, $2, $3, $4, $5, $6) RETURNING *
  `, [name, phone, email, company, message, source || 'website'])
  res.json(lead.rows[0])
})

// ========== ADMIN API ==========
app.post('/api/admin/login', async (req, res) => {
  const { email, password } = req.body
  const user = await pool.query('SELECT * FROM users WHERE email = $1', [email])
  if (!user.rows[0]) return res.status(401).json({ error: 'Invalid credentials' })

  const valid = await bcrypt.compare(password, user.rows[0].password_hash)
  if (!valid) return res.status(401).json({ error: 'Invalid credentials' })

  const token = jwt.sign(
    { id: user.rows[0].id, email: user.rows[0].email, role: user.rows[0].role },
    process.env.JWT_SECRET,
    { expiresIn: '24h' }
  )

  await pool.query('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = $1', [user.rows[0].id])
  res.json({ token, user: { id: user.rows[0].id, name: user.rows[0].full_name, role: user.rows[0].role } })
})

app.get('/api/admin/stats', auth, async (req, res) => {
  const total = await pool.query('SELECT COUNT(*) FROM chat_sessions')
  const active = await pool.query("SELECT COUNT(*) FROM chat_sessions WHERE status = 'active'")
  const today = await pool.query("SELECT COUNT(*) FROM chat_sessions WHERE created_at::date = CURRENT_DATE")
  res.json({
    total: parseInt(total.rows[0].count),
    active: parseInt(active.rows[0].count),
    today: parseInt(today.rows[0].count),
  })
})

const PORT = process.env.PORT || 3001
app.listen(PORT, () => console.log(`SMPL API running on port ${PORT}`))