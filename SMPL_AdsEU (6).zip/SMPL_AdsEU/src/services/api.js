// API Service for SMPL Ads
// TODO: Replace BASE_URL with your backend URL

const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api'

// Helper for fetch
async function fetchAPI(endpoint, options = {}) {
  const res = await fetch(`${BASE_URL}${endpoint}`, {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options,
  })
  if (!res.ok) throw new Error(`API Error: ${res.status}`)
  return res.json()
}

// ========== CHAT API ==========

export async function sendChatMessage({ sessionId, text, senderType = 'user', metadata = {} }) {
  // 1. Save to backend DB
  const saved = await fetchAPI('/chat/message', {
    method: 'POST',
    body: JSON.stringify({ sessionId, text, senderType, metadata }),
  })

  // 2. Forward to WhatsApp group (backend handles this)
  // The backend should call WhatsApp API (Ultramsg / CallMeBot / Meta Business API)
  await fetchAPI('/chat/forward-whatsapp', {
    method: 'POST',
    body: JSON.stringify({
      sessionId,
      text,
      // For Ultramsg: to = group ID (e.g. "120363000000000000@g.us")
      // For CallMeBot: phone = manager phone
      target: import.meta.env.VITE_WHATSAPP_GROUP_ID || '',
    }),
  }).catch(() => {
    // Silently fail — message is already saved, WhatsApp is best-effort
  })

  return saved
}

export async function getChatHistory(sessionId) {
  return fetchAPI(`/chat/history/${sessionId}`)
}

export async function getActiveChats() {
  return fetchAPI('/chat/active')
}

export async function managerReply({ sessionId, text, managerId }) {
  return fetchAPI('/chat/reply', {
    method: 'POST',
    body: JSON.stringify({ sessionId, text, managerId }),
  })
}

export async function markAsRead(sessionId) {
  return fetchAPI(`/chat/read/${sessionId}`, { method: 'POST' })
}

// ========== LEADS API ==========

export async function submitLead(data) {
  return fetchAPI('/leads', {
    method: 'POST',
    body: JSON.stringify(data),
  })
}

// ========== ADMIN API ==========

export async function adminLogin(credentials) {
  return fetchAPI('/admin/login', {
    method: 'POST',
    body: JSON.stringify(credentials),
  })
}

export async function getAdminStats() {
  return fetchAPI('/admin/stats')
}
