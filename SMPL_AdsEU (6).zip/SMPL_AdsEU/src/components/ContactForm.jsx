import { useState } from 'react'
import { motion } from 'framer-motion'
import { Send, CheckCircle, Loader2 } from 'lucide-react'

const ContactForm = () => {
  const [formData, setFormData] = useState({ name: '', phone: '' })
  const [status, setStatus] = useState('idle')
  const [errors, setErrors] = useState({})

  const validate = () => {
    const newErrors = {}
    if (!formData.name.trim()) newErrors.name = 'Name is required'
    if (!formData.phone.trim()) newErrors.phone = 'Phone is required'
    else if (!/[\d\s\-\+\(\)]+/.test(formData.phone)) newErrors.phone = 'Invalid phone format'
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!validate()) return

    setStatus('loading')

    try {
      await new Promise(resolve => setTimeout(resolve, 1500))
      // TODO: fetch('/api/leads', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(formData) })
      setStatus('success')
      setFormData({ name: '', phone: '' })
      setTimeout(() => setStatus('idle'), 3000)
    } catch (err) {
      setStatus('error')
    }
  }

  const handleChange = (e) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }))
    if (errors[e.target.name]) {
      setErrors(prev => ({ ...prev, [e.target.name]: undefined }))
    }
  }

  return (
    <section id="contact-form" className="py-20 bg-primary dark:bg-slate-950 text-white">
      <div className="container mx-auto px-4 max-w-xl text-center">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-3xl md:text-5xl font-bold mb-8 italic leading-tight"
        >
          "Ready to lead your market?"
        </motion.h2>

        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-3xl p-8 text-primary shadow-2xl"
        >
          {status === 'success' ? (
            <motion.div 
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              className="py-12 flex flex-col items-center gap-4"
            >
              <CheckCircle size={64} className="text-green-500" />
              <h3 className="text-2xl font-bold">Thank you!</h3>
              <p className="text-gray-600">We received your request. Our manager will contact you within an hour.</p>
            </motion.div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6 text-left">
              <div>
                <label className="block text-lg font-semibold mb-2">Your Name</label>
                <input 
                  type="text" 
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="John Doe" 
                  className={`w-full px-6 py-4 bg-gray-50 border rounded-xl focus:ring-2 focus:ring-accent outline-none transition ${
                    errors.name ? 'border-red-500 focus:ring-red-500' : 'border-gray-200'
                  }`}
                />
                {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
              </div>
              <div>
                <label className="block text-lg font-semibold mb-2">Phone Number</label>
                <input 
                  type="tel" 
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="+1 (___) ___-____" 
                  className={`w-full px-6 py-4 bg-gray-50 border rounded-xl focus:ring-2 focus:ring-accent outline-none transition ${
                    errors.phone ? 'border-red-500 focus:ring-red-500' : 'border-gray-200'
                  }`}
                />
                {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone}</p>}
              </div>
              <button 
                type="submit" 
                disabled={status === 'loading'}
                className="w-full bg-accent text-white py-5 rounded-xl text-xl font-bold hover:bg-accentHover transition disabled:opacity-70 flex items-center justify-center gap-2"
              >
                {status === 'loading' ? (
                  <>
                    <Loader2 className="animate-spin" size={24} />
                    Sending...
                  </>
                ) : (
                  <>
                    <Send size={20} />
                    Get Growth Plan
                  </>
                )}
              </button>
            </form>
          )}
        </motion.div>
      </div>
    </section>
  )
}

export default ContactForm