import { useState, useEffect, useRef } from 'react'
import { db, ref, onValue, push } from '../../lib/firebase'
import { Send, User, MessageSquare, CheckCheck, Trash2 } from 'lucide-react'

const AdminChat = () => {
  const [chats, setChats] = useState({})
  const [activeChat, setActiveChat] = useState(null)
  const [input, setInput] = useState('')
  const [search, setSearch] = useState('')
  const messagesEndRef = useRef(null)

  useEffect(() => {
    const chatsRef = ref(db, 'chats')
    const unsubscribe = onValue(chatsRef, (snapshot) => {
      setChats(snapshot.val() || {})
    })
    return () => unsubscribe()
  }, [])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [activeChat, chats])

  const activeMessages = activeChat && chats[activeChat]?.messages
    ? Object.entries(chats[activeChat].messages)
        .map(([id, val]) => ({ id, ...val }))
        .sort((a, b) => a.timestamp - b.timestamp)
    : []

  const sendReply = async () => {
    if (!input.trim() || !activeChat) return
    const messagesRef = ref(db, `chats/${activeChat}/messages`)
    await push(messagesRef, {
      text: input.trim(),
      sender: 'admin',
      timestamp: Date.now()
    })
    setInput('')
  }

  const deleteChat = (chatId) => {
    if (confirm('Delete this chat?')) {
      // Просто видаляємо з локального стану (в Firebase залишиться)
      if (activeChat === chatId) setActiveChat(null)
    }
  }

  const chatList = Object.entries(chats)
    .filter(([id, chat]) => {
      const msgs = chat.messages ? Object.values(chat.messages) : []
      const lastMsg = msgs[msgs.length - 1]
      const name = lastMsg?.name || 'Guest'
      return name.toLowerCase().includes(search.toLowerCase()) || id.includes(search)
    })
    .sort((a, b) => {
      const lastA = a[1].messages ? Math.max(...Object.values(a[1].messages).map(m => m.timestamp)) : 0
      const lastB = b[1].messages ? Math.max(...Object.values(b[1].messages).map(m => m.timestamp)) : 0
      return lastB - lastA
    })

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-slate-900 flex">
      {/* Sidebar */}
      <div className="w-80 bg-white dark:bg-darkBg border-r dark:border-gray-800 flex flex-col">
        <div className="p-4 border-b dark:border-gray-800">
          <h1 className="text-xl font-bold text-primary dark:text-white flex items-center gap-2">
            <MessageSquare size={20} className="text-accent" />
            SMPL Chat Admin
          </h1>
          <input
            type="text"
            placeholder="Search chats..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full mt-3 px-3 py-2 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-gray-700 rounded-lg text-sm outline-none focus:ring-2 focus:ring-accent"
          />
        </div>
        <div className="flex-1 overflow-y-auto">
          {chatList.map(([chatId, chat]) => {
            const msgs = chat.messages ? Object.values(chat.messages) : []
            const lastMsg = msgs[msgs.length - 1]
            const userMsgs = msgs.filter(m => m.sender === 'user')
            const adminMsgs = msgs.filter(m => m.sender === 'admin')
            const needsReply = userMsgs.length > adminMsgs.length

            return (
              <button
                key={chatId}
                onClick={() => setActiveChat(chatId)}
                className={`w-full text-left p-4 border-b dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-slate-800 transition relative ${
                  activeChat === chatId ? 'bg-accent/10 border-l-4 border-l-accent' : ''
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <User size={16} className="text-gray-400" />
                    <span className="font-semibold text-sm text-primary dark:text-white">
                      {lastMsg?.name || 'Guest'}
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    {needsReply && (
                      <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">Reply</span>
                    )}
                    <button 
                      onClick={(e) => { e.stopPropagation(); deleteChat(chatId) }}
                      className="text-gray-400 hover:text-red-500 p-1"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
                <p className="text-xs text-gray-500 mt-1 truncate">{lastMsg?.text || 'No messages'}</p>
                <p className="text-[10px] text-gray-400 mt-1">{chatId} • {msgs.length} msgs</p>
              </button>
            )
          })}
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col bg-white dark:bg-darkBg">
        {activeChat ? (
          <>
            <div className="p-4 border-b dark:border-gray-800 flex items-center justify-between">
              <div>
                <h2 className="font-bold text-primary dark:text-white">
                  {activeMessages.find(m => m.name)?.name || 'Guest'}
                </h2>
                <p className="text-xs text-gray-400">{activeChat}</p>
              </div>
              <button onClick={() => setActiveChat(null)} className="text-gray-400 hover:text-gray-600">Close</button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {activeMessages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.sender === 'admin' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[70%] p-3 rounded-2xl ${
                    msg.sender === 'admin'
                      ? 'bg-accent text-white rounded-tr-none'
                      : msg.sender === 'ai'
                      ? 'bg-gray-100 dark:bg-slate-800 text-primary dark:text-white rounded-tl-none'
                      : 'bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-200 rounded-tl-none'
                  }`}>
                    <div className="text-xs opacity-70 mb-1">
                      {msg.sender === 'admin' ? 'You (Manager)' : msg.sender === 'ai' ? 'Bot' : msg.name || 'User'}
                    </div>
                    <div className="text-sm">{msg.text}</div>
                    <div className={`text-[10px] mt-1 flex items-center gap-1 ${msg.sender === 'admin' ? 'text-white/60' : 'text-gray-400'}`}>
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      {msg.sender === 'admin' && <CheckCheck size={10} />}
                    </div>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
            <div className="p-4 border-t dark:border-gray-800 flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && sendReply()}
                placeholder="Type your reply..."
                className="flex-1 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-gray-700 rounded-xl px-4 py-2 outline-none focus:ring-2 focus:ring-accent text-primary dark:text-white"
              />
              <button
                onClick={sendReply}
                disabled={!input.trim()}
                className="bg-accent text-white px-4 py-2 rounded-xl hover:bg-accentHover transition disabled:opacity-50 flex items-center gap-2"
              >
                <Send size={16} /> Send
              </button>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-gray-400">
            <div className="text-center">
              <MessageSquare size={48} className="mx-auto mb-4 opacity-30" />
              <p>Select a chat to reply</p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default AdminChat