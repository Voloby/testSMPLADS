import { useState, useEffect } from 'react'
import { Menu, X, Sun, Moon } from 'lucide-react'

const Header = ({ toggleTheme, theme }) => {
  const [isOpen, setIsOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const navLinks = [
    { href: '#services', label: 'Services' },
    { href: '#home', label: 'About Us' },
    { href: '#why-us', label: 'Why Us' },
    { href: '#contacts', label: 'Contacts' },
  ]

  const handleNavClick = (e, href) => {
    e.preventDefault()
    const target = document.querySelector(href)
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' })
      setIsOpen(false)
    }
  }

  return (
    <header className={`sticky top-0 z-50 transition-all duration-300 ${
      scrolled 
        ? 'bg-white/90 dark:bg-darkBg/90 backdrop-blur-md shadow-sm border-b border-gray-100 dark:border-gray-800' 
        : 'bg-transparent'
    }`}>
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <span className="text-2xl font-bold tracking-tight">
            SMPL <span className="text-accent">Ads</span>
          </span>
        </div>

        <nav className="hidden md:flex space-x-8 text-lg font-medium items-center">
          {navLinks.map(link => (
            <a 
              key={link.href} 
              href={link.href} 
              onClick={(e) => handleNavClick(e, link.href)}
              className="hover:text-accent transition"
            >
              {link.label}
            </a>
          ))}
          <button 
            onClick={toggleTheme}
            className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition"
            aria-label="Toggle theme"
          >
            {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
          </button>
        </nav>

        <div className="flex items-center gap-4 md:hidden">
          <button 
            onClick={toggleTheme}
            className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition"
            aria-label="Toggle theme"
          >
            {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
          </button>
          <button 
            className="p-2" 
            onClick={() => setIsOpen(!isOpen)}
            aria-label="Toggle menu"
          >
            {isOpen ? <X size={32} /> : <Menu size={32} />}
          </button>
        </div>

        <a 
          href="#contact-form" 
          onClick={(e) => handleNavClick(e, '#contact-form')}
          className="hidden md:block bg-accent text-white px-6 py-3 rounded-lg font-semibold hover:bg-accentHover transition shadow-md"
        >
          Free Consultation
        </a>
      </div>

      <div className={`md:hidden transition-all duration-300 overflow-hidden ${
        isOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
      } bg-white dark:bg-darkBg border-t dark:border-gray-800 px-4 shadow-lg`}>
        <div className="py-4 space-y-4">
          {navLinks.map(link => (
            <a 
              key={link.href} 
              href={link.href} 
              onClick={(e) => handleNavClick(e, link.href)}
              className="block text-lg py-2"
            >
              {link.label}
            </a>
          ))}
          <a 
            href="#contact-form" 
            onClick={(e) => handleNavClick(e, '#contact-form')}
            className="block bg-accent text-white text-center px-6 py-3 rounded-lg font-semibold"
          >
            Consultation
          </a>
        </div>
      </div>
    </header>
  )
}

export default Header