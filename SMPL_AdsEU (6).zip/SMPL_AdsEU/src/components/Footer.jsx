import { MapPin, Mail, Phone } from 'lucide-react'

const Footer = () => {
  return (
    <footer id="contacts" className="bg-white dark:bg-darkBg border-t dark:border-gray-800 py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <div className="text-2xl font-bold mb-6 text-primary dark:text-white">
              SMPL <span className="text-accent">Ads</span>
            </div>
            <p className="text-gray-500 dark:text-gray-400 text-lg">
              Your reliable partner in the world of digital advertising. Making the complex simple, and the expensive profitable.
            </p>
          </div>
          <div>
            <h6 className="font-bold mb-4 text-primary dark:text-white">Offices</h6>
            <ul className="text-gray-500 dark:text-gray-400 space-y-3">
              <li className="flex items-center gap-2"><MapPin size={16} /> New Jersey, USA</li>
              <li className="flex items-center gap-2"><MapPin size={16} /> Dublin, Ireland</li>
              <li className="flex items-center gap-2"><MapPin size={16} /> Almaty, Kazakhstan</li>
              <li className="flex items-center gap-2 opacity-60 italic"><MapPin size={16} /> Toronto, Canada (Soon)</li>
            </ul>
          </div>
          <div>
            <h6 className="font-bold mb-4 text-primary dark:text-white">Contact</h6>
            <ul className="text-gray-500 dark:text-gray-400 space-y-3">
              <li className="flex items-center gap-2"><Mail size={16} /> info@smplads.com</li>
              <li className="flex items-center gap-2"><Phone size={16} /> +1 201 555-0123</li>
            </ul>
          </div>
        </div>
        <div className="text-center text-gray-400 text-sm border-t dark:border-gray-800 pt-8">
          &copy; {new Date().getFullYear()} SMPL Ads. We work for your results.
        </div>
      </div>
    </footer>
  )
}

export default Footer