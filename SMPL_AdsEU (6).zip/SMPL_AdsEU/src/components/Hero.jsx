import { motion } from 'framer-motion'
import { Star, ThumbsUp } from 'lucide-react'

const Hero = () => {
  return (
    <section id="home" className="py-20 bg-white dark:bg-darkBg">
      <div className="container mx-auto px-4 flex flex-col md:flex-row items-center gap-12">
        <div className="md:w-1/2">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="inline-flex items-center px-4 py-1.5 rounded-full bg-accent/10 border border-accent/20 text-accent text-sm font-bold mb-6"
          >
            <span className="relative flex h-2 w-2 mr-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-accent"></span>
            </span>
            Next-Generation Agency
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-6xl font-bold leading-tight mb-6"
          >
            Advertising that brings <span className="text-accent">profit</span>, not hassle.
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-gray-600 dark:text-gray-400 mb-8"
          >
            We are a team from New Jersey, Dublin, and Almaty. Working 24/7 to grow your business while you rest. A fresh perspective for your marketing.
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="flex flex-wrap gap-6 mb-8"
          >
            <div className="flex items-center space-x-2 bg-gray-50 dark:bg-slate-800 px-4 py-2 rounded-lg">
              <Star className="text-yellow-500 fill-yellow-500" size={18} />
              <span className="text-yellow-500 font-bold">4.9</span>
              <span className="text-sm font-medium">Google Maps</span>
            </div>
            <div className="flex items-center space-x-2 bg-gray-50 dark:bg-slate-800 px-4 py-2 rounded-lg">
              <ThumbsUp className="text-green-500" size={18} />
              <span className="text-green-500 font-bold">Trustpilot</span>
              <span className="text-sm font-medium">Excellent</span>
            </div>
          </motion.div>

          <motion.a 
            href="#contact-form"
            onClick={(e) => {
              e.preventDefault()
              document.querySelector('#contact-form')?.scrollIntoView({ behavior: 'smooth' })
            }}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="inline-block bg-primary text-white px-10 py-4 rounded-xl text-lg font-bold hover:bg-slate-800 transition shadow-lg"
          >
            Start Your Growth
          </motion.a>
        </div>

        <motion.div 
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="md:w-1/2"
        >
          <div className="rounded-3xl overflow-hidden shadow-2xl border-4 border-gray-100 dark:border-gray-800">
            <img 
              src="https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80" 
              alt="SMPL Team" 
              className="w-full h-auto hover:scale-105 transition-transform duration-700"
            />
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default Hero