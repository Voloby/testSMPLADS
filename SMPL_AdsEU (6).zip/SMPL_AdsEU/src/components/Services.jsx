import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Video, TrendingUp, Settings, Globe } from 'lucide-react'

const tabs = [
  {
    id: 'content',
    label: 'SMPL Content',
    icon: Video,
    title: 'Content That Sells',
    description: 'Short-form videos (Reels, TikTok) and authentic UGC reviews. We make your brand look alive, vibrant, and trustworthy.',
    features: ['Reels & TikTok Production', 'UGC Content Creation', 'Viral Scripting'],
    color: 'bg-purple-100 dark:bg-purple-900/20',
  },
  {
    id: 'traffic',
    label: 'SMPL Traffic',
    icon: TrendingUp,
    title: 'Customer Flow',
    description: 'Professional setup for Meta (FB/IG), Google Search, and TikTok Ads. We bring in people who are ready to buy.',
    features: ['Targeted Social Media Ads', 'Google Search & Display', 'High-ROI Retargeting'],
    color: 'bg-blue-100 dark:bg-blue-900/20',
  },
  {
    id: 'systems',
    label: 'SMPL Systems',
    icon: Settings,
    title: 'Sales Automation',
    description: 'Setting up lead processing so you never miss a customer. Everything is streamlined and automated for efficiency.',
    features: ['CRM Implementation', 'Lead Auto-responders', 'Sales Funnel Optimization'],
    color: 'bg-green-100 dark:bg-green-900/20',
  },
  {
    id: 'websites',
    label: 'SMPL Websites',
    icon: Globe,
    title: 'Modern Websites',
    description: 'Developing fast, minimalist, and user-friendly websites that work perfectly on smartphones and convert visitors into orders.',
    features: ['High-Conversion Landings', 'Full Mobile Optimization', 'Ultra-fast Loading Speeds'],
    color: 'bg-orange-100 dark:bg-orange-900/20',
  },
]

const Services = () => {
  const [activeTab, setActiveTab] = useState('content')
  const activeService = tabs.find(t => t.id === activeTab)

  return (
    <section id="services" className="py-20 bg-gray-50 dark:bg-slate-900/50">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-5xl font-bold mb-4"
          >
            Our Core Pillars
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-xl text-gray-500 dark:text-gray-400"
          >
            We've divided our services into 4 simple directions for your growth.
          </motion.p>
        </div>

        <div className="bg-white dark:bg-darkBg rounded-3xl shadow-xl overflow-hidden border border-gray-100 dark:border-gray-800">
          <div className="flex flex-col md:flex-row border-b border-gray-100 dark:border-gray-800">
            {tabs.map(tab => {
              const Icon = tab.icon
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex-1 py-6 px-4 text-lg font-semibold transition flex items-center justify-center gap-2 ${
                    activeTab === tab.id 
                      ? 'border-b-4 border-accent text-accent' 
                      : 'border-b-4 border-transparent hover:text-accent text-gray-500 dark:text-gray-400'
                  }`}
                >
                  <Icon size={20} />
                  {tab.label}
                </button>
              )
            })}
          </div>

          <div className="p-8 md:p-12 min-h-[400px]">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                className="flex flex-col md:flex-row items-center gap-10"
              >
                <div className="md:w-3/5">
                  <h3 className="text-2xl font-bold mb-4 text-accent">{activeService.title}</h3>
                  <p className="text-lg leading-relaxed text-gray-600 dark:text-gray-300 mb-6">
                    {activeService.description}
                  </p>
                  <ul className="space-y-3">
                    {activeService.features.map((feature, idx) => (
                      <motion.li 
                        key={idx}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: idx * 0.1 }}
                        className="flex items-center text-lg"
                      >
                        <span className="text-accent mr-3 text-xl">●</span>
                        {feature}
                      </motion.li>
                    ))}
                  </ul>
                </div>
                <div className="md:w-2/5">
                  <div className={`${activeService.color} rounded-2xl h-64 flex items-center justify-center`}>
                    <activeService.icon size={64} className="text-accent opacity-40" />
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Services