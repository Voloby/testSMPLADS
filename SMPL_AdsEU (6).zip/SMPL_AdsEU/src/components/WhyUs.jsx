import { motion } from 'framer-motion'
import { MapPin, Zap, Shield, Clock } from 'lucide-react'

const features = [
  {
    icon: MapPin,
    title: 'Global Presence',
    description: 'Offices in New Jersey, Dublin, and Almaty. Canada office opening soon.',
  },
  {
    icon: Zap,
    title: 'Fresh Energy',
    description: 'No outdated methods. We use AI and the latest algorithms of 2024 to stay ahead.',
  },
  {
    icon: Shield,
    title: 'Results First',
    description: 'While big agencies work for "volume", we work for your name and our reputation.',
  },
  {
    icon: Clock,
    title: '24/7 Control',
    description: 'Thanks to our cross-continental team, we are monitoring your ads around the clock.',
  },
]

const WhyUs = () => {
  return (
    <section id="why-us" className="py-24 bg-gray-50 dark:bg-slate-900/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-5xl font-bold mb-6"
          >
            Why Choose SMPL Ads
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto"
          >
            We are new on the market, and that is our greatest advantage. We work twice as hard, use only the latest tech, and value every single client.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, idx) => {
            const Icon = feature.icon
            return (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                whileHover={{ y: -10 }}
                className="bg-white dark:bg-darkBg p-8 rounded-3xl border border-gray-100 dark:border-gray-800 shadow-sm hover:shadow-xl transition-all duration-300"
              >
                <div className="text-accent mb-4">
                  <Icon size={40} strokeWidth={1.5} />
                </div>
                <h4 className="text-xl font-bold mb-2">{feature.title}</h4>
                <p className="text-gray-500 dark:text-gray-400">{feature.description}</p>
              </motion.div>
            )
          })}
        </div>
      </div>
    </section>
  )
}

export default WhyUs