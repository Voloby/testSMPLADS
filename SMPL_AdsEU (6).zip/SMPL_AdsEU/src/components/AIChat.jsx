import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { MessageCircle, X, Send, Bot, User, Phone } from 'lucide-react'
import { db, ref, push, onValue } from '../lib/firebase'

const WHATSAPP_NUMBER = '12015550123'

const AIChat = () => {
  const [isOpen, setIsOpen] = useState(false)
  const [input, setInput] = useState('')
  const [messages, setMessages] = useState([])
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef(null)

  const [sessionId] = useState(() => {
    let id = localStorage.getItem('smpl_chat_session')
    if (!id) {
      id = 'guest_' + Math.random().toString(36).substr(2, 9)
      localStorage.setItem('smpl_chat_session', id)
    }
    console.log('Session ID:', id)
    return id
  })

  const [userInfo, setUserInfo] = useState(() => {
    const saved = localStorage.getItem('smpl_chat_user')
    return saved ? JSON.parse(saved) : { name: '', phone: '', step: 'ask_name' }
  })

  useEffect(() => {
    console.log('Connecting to Firebase path:', `chats/${sessionId}/messages`)
    const messagesRef = ref(db, `chats/${sessionId}/messages`)
    const unsubscribe = onValue(messagesRef, (snapshot) => {
      const data = snapshot.val()
      console.log('Firebase data received:', data)
      if (data) {
        const msgs = Object.entries(data).map(([id, val]) => ({ id, ...val }))
        setMessages(msgs.sort((a, b) => a.timestamp - b.timestamp))
      } else {
        setMessages([])
      }
    }, (error) => {
      console.error('Firebase read error:', error)
    })
    return () => unsubscribe()
  }, [sessionId])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const sendMessage = async (text, sender = 'user') => {
    try {
      const messagesRef = ref(db, `chats/${sessionId}/messages`)
      console.log('Sending to Firebase:', { text, sender, sessionId })
      await push(messagesRef, {
        text,
        sender,
        timestamp: Date.now(),
        name: userInfo.name || 'Guest',
        phone: userInfo.phone || ''
      })
      console.log('✅ Message sent successfully')
    } catch (error) {
      console.error('❌ Firebase send error:', error)
      alert('Error sending message. Check console (F12).')
    }
  }

  const handleSend = async () => {
    if (!input.trim()) return
    const text = input.trim()
    setInput('')

    if (userInfo.step === 'ask_name') {
      setUserInfo(prev => {
        const updated = { ...prev, name: text, step: 'ask_phone' }
        localStorage.setItem('smpl_chat_user', JSON.stringify(updated))
        return updated
      })
      await sendMessage(text, 'user')
      setTimeout(() => sendMessage(`Nice to meet you, ${text}! What's your phone number?`, 'ai'), 500)
      return
    }

    if (userInfo.step === 'ask_phone') {
      setUserInfo(prev => {
        const updated = { ...prev, phone: text, step: 'chat' }
        localStorage.setItem('smpl_chat_user', JSON.stringify(updated))
        return updated
      })
      await sendMessage(text, 'user')
      setTimeout(() => sendMessage("✅ Thank you! Our manager will reply here shortly. Keep chatting!", 'ai'), 500)
      return
    }

    await sendMessage(text, 'user')
  }

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const hasNewAdminMsg = messages.some(m => m.sender === 'admin')

  return (
    <div className="fixed bottom-6 right-6 z-[100]">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="absolute bottom-20 right-0 w-80 md:w-96 bg-white dark:bg-darkBg rounded-3xl shadow-2xl border border-gray-100 dark:border-gray-800 overflow-hidden flex flex-col"
          >
            <div className="bg-accent p-4 text-white font-bold flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Bot size={20} />
                <div>
                  <div>SMPL Support</div>
                  <div className="text-xs font-normal opacity-80 flex items-center gap-1">
                    <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
                    {hasNewAdminMsg ? 'Manager is online' : 'We reply within 15 min'}
                  </div>
                </div>
              </div>
              <button onClick={() => setIsOpen(false)} className="hover:bg-white/20 rounded-full p-1 transition">
                <X size={18} />
              </button>
            </div>

            <div className="h-80 overflow-y-auto p-4 space-y-4 text-sm bg-gray-50 dark:bg-slate-900/50">
              {messages.length === 0 && (
                <div className="text-center text-gray-400 py-8">
                  <MessageCircle size={40} className="mx-auto mb-2 opacity-30" />
                  <p>Start a conversation!</p>
                </div>
              )}
              {messages.map((msg) => (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-[85%] p-3 rounded-2xl ${
                    msg.sender === 'user'
                      ? 'bg-accent text-white rounded-tr-none'
                      : msg.sender === 'admin'
                      ? 'bg-green-600 text-white rounded-tl-none'
                      : 'bg-white dark:bg-slate-800 text-primary dark:text-white rounded-tl-none shadow-sm border border-gray-100 dark:border-gray-700'
                  }`}>
                    <div className="text-xs opacity-70 mb-1 flex items-center gap-1">
                      {msg.sender === 'admin' && <User size={10} />}
                      {msg.sender === 'admin' ? 'Manager' : msg.sender === 'ai' ? 'Bot' : 'You'}
                    </div>
                    <div className="text-sm">{msg.text}</div>
                    <div className={`text-[10px] mt-1 ${msg.sender === 'user' ? 'text-white/60' : 'text-gray-400'}`}>
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                </motion.div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            <div className="p-4 border-t dark:border-gray-800 bg-white dark:bg-darkBg flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyPress}
                placeholder={
                  userInfo.step === 'ask_name' ? "Your name..." :
                  userInfo.step === 'ask_phone' ? "Your phone..." :
                  "Type a message..."
                }
                className="flex-1 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-gray-700 rounded-xl px-4 py-2 outline-none focus:ring-2 focus:ring-accent text-primary dark:text-white placeholder-gray-400 text-sm"
              />
              <button
                onClick={handleSend}
                disabled={!input.trim()}
                className="bg-accent text-white p-2 rounded-xl hover:bg-accentHover transition disabled:opacity-50"
              >
                <Send size={18} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(!isOpen)}
        className="bg-accent text-white w-16 h-16 rounded-full shadow-2xl flex items-center justify-center hover:shadow-accent/50 transition-shadow relative"
      >
        {isOpen ? <X size={28} /> : <MessageCircle size={28} />}
      </motion.button>
    </div>
  )
}

export default AIChat